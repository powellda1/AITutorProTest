import { useState, useEffect } from 'react';
import { generateUniversalCardHeader, generateUniversalComponentJSX, generateUniversalPrompt, UniversalPromptConfig, universalInputStyles } from '../utils/universalRenderer';

export interface GridComponentProps {
  gridSize: number; // Total number of cells (e.g., 100 for 10x10)
  columns: number; // Number of columns (e.g., 10 for 10x10)
  preShadedCells?: number[]; // Array of cell indices that should be pre-shaded
  mode: 'view-only' | 'clickable' | 'identify-percentage';
  correctAnswer?: string | number;
  promptText?: string;
  onAnswer: (answer: string | number) => void;
  selectedCells?: number[]; // For externally controlled selection
  onCellsChange?: (cells: number[]) => void;
  resetTrigger?: number; // When this changes, reset the component state
  standardCode?: string; // For universal system integration
  lessonTitle?: string; // For universal system integration
}

function GridComponent({
  gridSize,
  columns,
  preShadedCells = [],
  mode,
  correctAnswer,
  promptText,
  onAnswer,
  selectedCells,
  onCellsChange,
  resetTrigger,
  standardCode,
  lessonTitle
}: GridComponentProps) {
  const [internalSelectedCells, setInternalSelectedCells] = useState<number[]>([]);
  const [userAnswer, setUserAnswer] = useState('');

  // Reset component state when resetTrigger changes
  useEffect(() => {
    if (resetTrigger !== undefined) {
      setUserAnswer('');
      setInternalSelectedCells([]);
    }
  }, [resetTrigger]);

  // Use external selection if provided, otherwise use internal state
  const currentSelectedCells = selectedCells || internalSelectedCells;
  const setCurrentSelectedCells = onCellsChange || setInternalSelectedCells;

  const rows = Math.ceil(gridSize / columns);

  const handleCellClick = (cellIndex: number) => {
    if (mode === 'view-only') return;

    if (mode === 'clickable') {
      const newSelection = currentSelectedCells.includes(cellIndex)
        ? currentSelectedCells.filter(i => i !== cellIndex)
        : [...currentSelectedCells, cellIndex];
      setCurrentSelectedCells(newSelection);
    }
  };

  const handleSubmit = () => {
    if (mode === 'identify-percentage') {
      // User enters percentage they see
      if (userAnswer.trim()) {
        onAnswer(userAnswer.trim());
      }
    } else if (mode === 'clickable') {
      // User has selected cells, calculate percentage
      const percentage = (currentSelectedCells.length / gridSize) * 100;
      onAnswer(percentage.toString());
    }
  };

  // Universal configuration for this component
  const universalConfig: UniversalPromptConfig = {
    type: 'grid-percentage',
    standardCode: standardCode || '6.NS.1.a',
    lessonTitle: lessonTitle || 'Grid Model Practice',
    context: { preShadedCells: preShadedCells.length, gridSize, mode }
  };

  const headerConfig = generateUniversalCardHeader(universalConfig);
  const universalPrompt = generateUniversalPrompt(universalConfig);
  
  // DEBUG: Log when GridComponent is rendered
  console.log('🎯 GridComponent rendered with universalPrompt:', universalPrompt);
  console.log('🎯 GridComponent standardCode:', standardCode);
  console.log('🎯 GridComponent lessonTitle:', lessonTitle);

  const getCellClass = (cellIndex: number) => {
    const isPreShaded = preShadedCells.includes(cellIndex);
    const isSelected = currentSelectedCells.includes(cellIndex);
    const isClickable = mode === 'clickable';

    return `
      grid-cell
      ${isPreShaded ? 'grid-cell-pre-shaded' : ''}
      ${isSelected ? 'grid-cell-selected' : ''}
      ${!isPreShaded && !isSelected ? 'grid-cell-empty' : ''}
      ${isClickable ? 'grid-cell-clickable' : ''}
    `.trim();
  };

  const renderGrid = () => {
    return (
      <div 
        className="grid-container"
        style={{
          gridTemplateColumns: `repeat(${columns}, 1fr)`,
          gridTemplateRows: `repeat(${rows}, 1fr)`
        }}
      >
        {Array.from({ length: gridSize }, (_, i) => (
          <div
            key={i}
            className={getCellClass(i)}
            onClick={() => handleCellClick(i)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="text-center mb-4">
      {/* Universal header */}
      <div className="bg-gray-600 p-4 rounded-lg border-2 border-gray-400 mb-4">
        <div className="text-lg text-white mb-4 font-semibold">
          {universalPrompt}
        </div>
        
        {/* Grid visualization */}
        <div className="grid-wrapper">
          {renderGrid()}
        </div>
        
        {/* Grid status for clickable mode */}
        {mode === 'clickable' && (
          <div className="text-sm text-white mt-2 font-medium">
            {currentSelectedCells.length} out of {gridSize} cells selected
            ({Math.round((currentSelectedCells.length / gridSize) * 100)}%)
          </div>
        )}
      </div>
      
      {/* Universal input and submit section */}
      {mode === 'identify-percentage' && (
        <div className="flex items-center justify-center space-x-2">
          <input
            type="text"
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            placeholder="Enter percentage (e.g., 20%)"
            className="w-32 px-3 py-2 border border-gray-600 rounded text-white bg-[#35373b] placeholder-gray-300"
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSubmit();
              }
            }}
          />
          <button 
            onClick={handleSubmit}
            disabled={!userAnswer.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400"
          >
            Submit
          </button>
        </div>
      )}
      
      {/* Submit button for clickable mode */}
      {mode === 'clickable' && (
        <div className="flex items-center justify-center">
          <button 
            onClick={handleSubmit}
            disabled={currentSelectedCells.length === 0}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400"
          >
            Submit
          </button>
        </div>
      )}
    </div>
  );
}

export default GridComponent;